package com.example.br600transfer

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.IOException

class MainActivity : ComponentActivity() {
    private var sourceTree: Uri? = null
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val audio = listOf(".wav", ".mp3", ".aif", ".aiff", ".mid", ".midi")

    private val chooseSource = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            sourceTree = uri
            status.text = "Folder selected. Scanning for audio files…"
            scan()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 20)
        }
        val title = TextView(this).apply {
            text = "BR-600 Transfer"
            textSize = 26f
        }
        status = TextView(this).apply {
            text = "Connect the BR-600 by USB, or insert its card into a reader. Then choose its folder."
            textSize = 15f
            setPadding(0, 16, 0, 16)
        }
        val select = Button(this).apply {
            text = "Choose recorder folder"
            setOnClickListener { chooseSource.launch(null) }
        }
        val refresh = Button(this).apply {
            text = "Rescan"
            setOnClickListener { scan() }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(title)
        root.addView(status)
        root.addView(select)
        root.addView(refresh)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun scan() {
        list.removeAllViews()
        val uri = sourceTree
        if (uri == null) {
            status.text = "Choose the recorder folder first."
            return
        }
        val root = DocumentFile.fromTreeUri(this, uri)
        if (root == null) {
            status.text = "Can't read that folder. Please select it again."
            return
        }
        val found = mutableListOf<DocumentFile>()
        fun walk(dir: DocumentFile) {
            dir.listFiles().forEach { f ->
                if (f.isDirectory) walk(f)
                else if (audio.any { f.name?.lowercase()?.endsWith(it) == true }) found.add(f)
            }
        }
        try { walk(root) } catch (_: Exception) {
            status.text = "Couldn't scan this location. Try selecting a different folder."
            return
        }
        status.text = "${found.size} possible audio file(s) found."
        if (found.isEmpty()) {
            val note = TextView(this).apply {
                text = "No common audio files found. The BR-600 may store projects in a proprietary folder structure or may not expose files to Android over USB. Try a CompactFlash card reader."
                textSize = 14f
                setPadding(0, 18, 0, 0)
            }
            list.addView(note)
        }
        found.forEach { file ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 12, 0, 12)
            }
            val name = TextView(this).apply {
                text = file.name ?: "Unnamed audio"
                textSize = 16f
            }
            val copy = Button(this).apply {
                text = "Copy to phone"
                setOnClickListener { copyFile(file) }
            }
            row.addView(name)
            row.addView(copy)
            list.addView(row)
            val line = View(this)
            list.addView(line, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private val chooseDestination = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        val pending = pendingFile
        if (uri != null && pending != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            try {
                val dest = DocumentFile.fromTreeUri(this, uri)
                    ?: throw IOException("Destination unavailable")
                val name = pending.name ?: "recording.wav"
                val out = dest.createFile("audio/wav", name)
                    ?: throw IOException("Couldn't create destination file")
                contentResolver.openInputStream(pending.uri)?.use { input ->
                    contentResolver.openOutputStream(out.uri)?.use { output ->
                        input.copyTo(output)
                    } ?: throw IOException("Couldn't open destination")
                } ?: throw IOException("Couldn't read source")
                status.text = "Copied: $name"
            } catch (e: Exception) {
                status.text = "Copy failed: ${e.message ?: "unknown error"}"
            }
            pendingFile = null
        }
    }
    private var pendingFile: DocumentFile? = null

    private fun copyFile(file: DocumentFile) {
        pendingFile = file
        status.text = "Choose a folder on your phone for ${file.name}"
        chooseDestination.launch(null)
    }
}
