# BR-600 Transfer (Android starter app)

This is a small Kotlin Android app that lets you select a folder Android can access, find common audio files, and copy a selected file to a folder on the phone.

## Build
1. Install Android Studio.
2. Open this project folder.
3. Allow Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled (or build an APK).
5. Run the app.

## Important BR-600 USB limitation
This app uses Android's Storage Access Framework. It does not implement the Boss BR-600's proprietary USB protocol. It will work only if Android exposes the recorder/card as a browsable folder. If the recorder is not listed in the folder picker, try removing the CompactFlash card and using a USB-C CompactFlash reader (and select the mounted card if Android exposes it).

The app currently copies common audio extensions (.wav, .mp3, .aif, .aiff, .mid, .midi). BR-600 project data may require Boss-compatible conversion software and may not be usable as a standalone WAV simply by copying. Always keep the original project/card intact.

## Getting an installable APK (no Android Studio needed)
This project includes a GitHub Actions workflow (`.github/workflows/build-apk.yml`) that builds a debug APK in the cloud.

1. Create a new repo on GitHub (public or private).
2. Upload/push everything in this folder to that repo.
3. Go to the repo's **Actions** tab — a "Build APK" run should start automatically (or click "Run workflow" to trigger it manually).
4. When it finishes (green check), open the run and download the **BR600-Transfer-debug-apk** artifact (a zip containing `app-debug.apk`).
5. Transfer `app-debug.apk` to your phone (email, Drive, USB, etc.), tap it, and allow "install unknown apps" for that source when prompted.

This is a debug build — fine for installing on your own device, not for the Play Store.
